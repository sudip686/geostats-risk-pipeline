"""
utils/io.py - Input/Output utilities
"""

import os
import json
import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


def load_data(data_dir):
    """Load standard drillhole CSV files."""
    try:
        collar = pd.read_csv(os.path.join(data_dir, 'collar.csv'))
        survey = pd.read_csv(os.path.join(data_dir, 'survey.csv'))
        assay = pd.read_csv(os.path.join(data_dir, 'assay.csv'))
        litho = pd.read_csv(os.path.join(data_dir, 'lithology.csv'))
    except FileNotFoundError as e:
        logger.error(f"Error loading data: {e}")
        return None, None, None, None

    # Standardize columns (strip whitespace, lower case)
    for df in [collar, survey, assay, litho]:
        df.columns = df.columns.str.strip().str.lower()

    return collar, survey, assay, litho


def save_grid(grid_dict, output_dir, prefix='sgs'):
    """Save grid to numpy and metadata JSON."""
    os.makedirs(output_dir, exist_ok=True)

    np.save(
        os.path.join(output_dir, f'{prefix}_reals.npy'),
        grid_dict['realizations']
    )

    meta = {
        'x_min': float(grid_dict['x'].min()),
        'x_max': float(grid_dict['x'].max()),
        'y_min': float(grid_dict['y'].min()),
        'y_max': float(grid_dict['y'].max()),
        'z_min': float(grid_dict['z'].min()),
        'z_max': float(grid_dict['z'].max()),
        'dx': float(grid_dict['x'][1] - grid_dict['x'][0]) if len(grid_dict['x']) > 1 else float(grid_dict['dx']),
        'dy': float(grid_dict['y'][1] - grid_dict['y'][0]) if len(grid_dict['y']) > 1 else float(grid_dict['dy']),
        'dz': float(grid_dict['z'][1] - grid_dict['z'][0]) if len(grid_dict['z']) > 1 else float(grid_dict['dz']),
        'shape': grid_dict['realizations'].shape
    }

    with open(os.path.join(output_dir, f'{prefix}_meta.json'), 'w') as f:
        json.dump(meta, f, indent=2)


def load_config(config_path):
    """Load YAML configuration."""
    import yaml
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


def save_metadata(meta, output_path):
    """Save metadata to JSON."""
    with open(output_path, 'w') as f:
        json.dump(meta, f, indent=2)


def load_npy(path):
    """Load numpy array."""
    return np.load(path)


def save_csv(df, output_path):
    """Save DataFrame to CSV."""
    df.to_csv(output_path, index=False)
    logger.info(f"Saved {output_path}")

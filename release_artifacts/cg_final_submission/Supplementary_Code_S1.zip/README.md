# Tanga_New

Current reproducible workflow for SGS modeling and submission package generation.

## Folder Layout

- `config/`: workflow configs.
- `data/`: canonical drillhole inputs (`assay`, `collar`, `lithology`, `survey`).
- `src/`: modeling and validation code.
- `scripts/`: build/orchestration scripts.
- `output/`: run outputs.
- `submission/`: final submission package artifacts (clean required-file set).
- `submission_ready/`: upstream build output/template source used to regenerate `submission/`.
- `review/`: review and audit notes.
- `build/`: source-of-truth metadata outputs.

## Manuscript Naming (Current)

- Primary submission manuscript file is `submission_ready/sudip_manuscript.docx`.
- Template/reference style file name remains `SG Manuscript.docx` (used as formatting reference, not packaged as primary manuscript).
- Packaging includes `sudip_manuscript.docx` instead of `SG Manuscript.docx`.

## Drillhole Policy (Locked for Rebuilds)

- Study drillholes used: `100`.
- Survey records may exist for `104` holes.
- Policy: 4 holes without complete assay/lithology support are excluded from study metrics.
- Strict rebuild checks fail if manuscript text does not include this policy.

## How To Run (By Level)

### Level 1: Quick Rebuild (most users)

1. Build submission package from latest canonical run:
   - `python scripts/build_submission_package.py`
2. Regenerate clean deliverable folder with fixed file names:
   - `python scripts/rebuild_submission_folder.py`
3. Final output is refreshed in:
   - `submission/`

### Level 2: Strict Rebuild (recommended before delivery)

1. Run strict checks and build:
   - `python scripts/build_submission_package.py --strict`
2. This validates:
   - required files
   - manuscript/content sync checks
   - table/equation visual structure checks
   - drillhole policy markers (100 used, 104 survey context)

### Level 3: Explicit Run Directory (advanced)

1. Build from a specific run:
   - `python scripts/build_submission_package.py --run-dir output/<run_name> --strict`
2. Optional custom output folder:
   - `python scripts/build_submission_package.py --run-dir output/<run_name> --out-dir submission_ready_custom --strict`

## Template Resolution

`build_submission_package.py` resolves templates from:

1. `_archive_20260307/Format/` (if present)
2. `submission_ready/` (fallback)

This allows rebuilds to work even after archive cleanup.

## Troubleshooting

- If you get `Missing template: ... Title page.docx`, ensure `submission_ready/Title page.docx` exists.
- If strict mode fails on drillhole text checks, regenerate through the build script and keep the policy line unchanged.

## Traceability

- Full file inventory: `FILES_MANIFEST.csv`.

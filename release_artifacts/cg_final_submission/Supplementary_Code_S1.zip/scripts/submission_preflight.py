#!/usr/bin/env python
from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SUB = ROOT / "submission_ready"
TRUTH = SUB / "source_of_truth.submission.json"
PAPER = SUB / "paper.md"
BODY = SUB / "paper_body.md"
TABLES = SUB / "tables_final.md"
CAPTIONS = SUB / "figure_captions_final.md"
PAPER_DOCX = SUB / "paper.docx"
ZIP = ROOT / "submission_package_final_clean.zip"


def fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    raise SystemExit(1)


def require(path: Path) -> None:
    if not path.exists():
        fail(f"Missing required artifact: {path}")


def load_truth() -> dict:
    require(TRUTH)
    return json.loads(TRUTH.read_text(encoding="utf-8"))


def check_truth_numbers(truth: dict) -> None:
    txt = PAPER.read_text(encoding="utf-8") + "\n" + BODY.read_text(encoding="utf-8") + "\n" + TABLES.read_text(encoding="utf-8") + "\n" + CAPTIONS.read_text(encoding="utf-8")
    expected = [
        str(truth["simulation"]["n_real"]),
        "13 x 46 x 27",
        "100 m x 100 m x 10 m",
        "0.055",
        "2.43",
        "209.50/210.50/211.30",
        "4.91",
        "0.9845",
        "0.0572",
        "0.5608 / 0.6291 / 0.4020",
    ]
    for token in expected:
        if token not in txt:
            fail(f"Expected truth-aligned token not found: {token}")


def check_refs_and_figures() -> None:
    require(SUB / "references.bib")
    fig_refs = re.findall(r"\*\*Figure\s+([0-9]+[A-Z]?)\.", CAPTIONS.read_text(encoding="utf-8"))
    if not fig_refs:
        fail("No figure captions found")
    figs = list((SUB / "figures").glob("*"))
    if len(figs) < len(fig_refs):
        fail("Figure files fewer than figure captions")


def check_zip() -> None:
    require(ZIP)
    with zipfile.ZipFile(ZIP) as z:
        names = set(z.namelist())
    required = {
        "source_of_truth.submission.json",
        "references.bib",
        "paper.md",
        "paper_body.md",
        "paper.docx",
        "tables_final.md",
        "figure_captions_final.md",
        "figures/figure_1_regional_geology_map.png",
    }
    missing = sorted(required - names)
    if missing:
        fail(f"Zip missing required entries: {missing}")


def main() -> None:
    for p in [PAPER, BODY, TABLES, CAPTIONS, PAPER_DOCX]:
        require(p)
    truth = load_truth()
    check_truth_numbers(truth)
    check_refs_and_figures()
    check_zip()
    print("OK: submission preflight passed")


if __name__ == "__main__":
    main()

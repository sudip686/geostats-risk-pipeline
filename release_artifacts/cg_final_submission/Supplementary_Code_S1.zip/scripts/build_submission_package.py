from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import textwrap
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parents[1]
SUBMISSION_DIR = ROOT / "submission_ready"
FINAL_SUBMISSION_DIR = ROOT / "submission_final_JAES"
FORMAT_DIR_CANDIDATES = [
    ROOT / "_archive_20260307" / "Format",
    ROOT / "submission_ready",
    ROOT / "submission",
    ROOT / "repo",
]
SOURCE_OF_TRUTH_JSON = ROOT / "build" / "source_of_truth.submission.json"
CANONICAL_N_REAL = 400
CANONICAL_SEARCH_RADIUS = [250, 120, 70]
PRIMARY_MANUSCRIPT_DOCX = "sudip_manuscript.docx"
PRIMARY_MANUSCRIPT_TEMPLATE = "SG Manuscript.docx"
STYLE_LOCK_REFERENCE = ROOT / "SG Manuscript (1).docx"
AUTHOR_NAME = "Sudipta Chanda"
AUTHOR_AFFILIATION = (
    "Sakariya Mines and Minerals, 1402 Ecostation Business Tower, Newtown, Rajarhat, Kolkata, West Bengal 700160"
)
AUTHOR_EMAIL = "sudipta.chanda@sakariya.in"

DOC_TEMPLATES = [
    "Title page.docx",
    "Covering Letter-MS.docx",
    PRIMARY_MANUSCRIPT_TEMPLATE,
    "Authors Statement.docx",
    "Conflict of interest.docx",
    "Declaration of interest statement.docx",
    "Fig.docx",
    "Table.docx",
]

REQUIRED_SUBMISSION_REL_PATHS = [
    "submission_ready/Title page.docx",
    "submission_ready/Covering Letter-MS.docx",
    f"submission_ready/{PRIMARY_MANUSCRIPT_DOCX}",
    "submission_ready/paper.docx",
    "submission_ready/Authors Statement.docx",
    "submission_ready/Conflict of interest.docx",
    "submission_ready/Declaration of interest statement.docx",
    "submission_ready/Fig.docx",
    "submission_ready/Table.docx",
    "submission_ready/paper.md",
    "submission_ready/paper_body.md",
    "submission_ready/tables_final.md",
    "submission_ready/figure_captions_final.md",
    "submission_ready/references.bib",
    "submission_ready/highlights.txt",
    "submission_ready/graphical_abstract_summary.txt",
    "submission_ready/figures",
    "submission_ready/supplement",
    "submission_ready/supplement/software_manifest.json",
    "submission_ready/supplement/synthetic_validation_reference.csv",
    "submission_ready/supplement/cross_validation_300.json",
    "submission_ready/supplement/cross_validation_600.json",
    "submission_ready/supplement/cross_validation_blocked_300.json",
    "submission_ready/SUBMISSION_CHECKLIST.md",
    "submission_ready/source_of_truth.submission.json",
    "submission_ready/SOURCE_OF_TRUTH.md",
    "submission_ready/submission_package_final_clean.zip",
    "submission_package_final_clean.zip",
]
INNER_BORDER_SZ = 12  # 1.5pt (Word size unit is 1/8 pt)
OUTER_BORDER_SZ = 20  # 2.5pt
EQ_BORDER_SZ = 16
FIGURE_IMAGE_MAP: dict[str, str] = {
    "1": "figure_1_regional_geology_map.png",
    "2": "variogram.png",
    "3": "histogram_validation.png",
    "4": "qq_plot.png",
    "5A": "swath_x.png",
    "5B": "swath_y.png",
    "5C": "swath_z.png",
    "6": "variogram_reproduction.png",
    "7": "tonnage_risk_curve.png",
}
FIGURE_DEFAULT_DETAILS: dict[str, str] = {
    "1": "Base geology after Geological Survey of Tanzania regional compilation; structural context from cited literature.",
    "2": "Source: source-of-truth workflow output (`output/.../figures/variogram.png`).",
    "3": "Source: source-of-truth workflow output (`output/.../figures/histogram_validation.png`).",
    "4": "Source: source-of-truth workflow output (`output/.../figures/qq_plot.png`).",
    "5A": "Source: source-of-truth workflow output (`output/.../figures/swath_x.png`).",
    "5B": "Source: source-of-truth workflow output (`output/.../figures/swath_y.png`).",
    "5C": "Source: source-of-truth workflow output (`output/.../figures/swath_z.png`).",
    "6": "Source: source-of-truth workflow output (`output/.../figures/variogram_reproduction.png`).",
    "7": "Source: source-of-truth workflow output (`submission_ready/figures/tonnage_risk_curve.png`).",
}
FINAL_SUBMISSION_REQUIRED_FILES = [
    "01_Title_Page.docx",
    "02_Highlights.docx",
    "03_Graphical_Abstract.tif",
    "04_Manuscript.docx",
    "05_Declaration_of_Interest.docx",
    "Figure_1.tif",
    "Figure_2.tif",
    "Figure_3.tif",
    "Figure_4.tif",
    "Figure_5A.tif",
    "Figure_5B.tif",
    "Figure_5C.tif",
    "Figure_6.tif",
    "Figure_7.tif",
    "Supplementary_Data_S1.zip",
    "Supplementary_Data_S2.zip",
    "Supplementary_Code_S1.zip",
    "Supplementary_Table_S1.csv",
    "Supplementary_Table_S2.csv",
    "Cover_Letter.docx",
    "Reviewer_Suggestions.docx",
    "Submission_Checklist.pdf",
]


def resolve_format_dir() -> Path:
    for d in FORMAT_DIR_CANDIDATES:
        if d.exists() and (d / "Title page.docx").exists():
            return d
    searched = ", ".join(str(p) for p in FORMAT_DIR_CANDIDATES)
    raise FileNotFoundError(
        "Could not resolve template directory. Expected to find `Title page.docx` in one of: "
        f"{searched}"
    )


def template_path(filename: str) -> Path:
    base = resolve_format_dir()
    candidates = [filename]
    if filename == PRIMARY_MANUSCRIPT_TEMPLATE:
        candidates = [PRIMARY_MANUSCRIPT_TEMPLATE, "paper.docx", PRIMARY_MANUSCRIPT_DOCX]
    for name in candidates:
        p = base / name
        if p.exists():
            return p
    # Return the primary candidate for clear error messages upstream.
    return base / filename


def _table_numbers_in_tables_md(text: str) -> set[int]:
    nums = set()
    for m in re.finditer(r"^##\s+Table\s+(\d+)\b", text, flags=re.IGNORECASE | re.MULTILINE):
        nums.add(int(m.group(1)))
    return nums


def _table_refs_in_text(text: str) -> list[int]:
    refs: list[int] = []
    for m in re.finditer(r"\bTable\s+(\d+)\b", text, flags=re.IGNORECASE):
        refs.append(int(m.group(1)))
    return refs


def verify_submission_content() -> list[str]:
    issues: list[str] = []
    paper = read_text(SUBMISSION_DIR / "paper.md")
    paper_body = read_text(SUBMISSION_DIR / "paper_body.md")
    tables_md = read_text(SUBMISSION_DIR / "tables_final.md")
    truth = json.loads(read_text(SUBMISSION_DIR / "source_of_truth.submission.json"))
    available_tables = _table_numbers_in_tables_md(tables_md)

    # 1) Table references in narrative must exist in tables_final.md
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        bad_refs = sorted(set(n for n in _table_refs_in_text(txt) if n not in available_tables))
        if bad_refs:
            issues.append(f"{name}: references non-existent tables {bad_refs}; available={sorted(available_tables)}")

    # 2) Duplicate reproduction paragraph guard
    phrase = "Reproduction is reported in two matched spaces"
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        c = txt.count(phrase)
        if c > 1:
            issues.append(f"{name}: duplicated variogram-reproduction paragraph ({c} occurrences)")

    # 3) Variogram practical-range inconsistency guard
    bad_range_patterns = [
        r"practical ranges?\s+of\s+237\.5",
        r"188\.5\s*m\s*\(down dip\)",
        r"112\.5\s*m\s*\(normal to plane\)",
    ]
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        for pat in bad_range_patterns:
            if re.search(pat, txt, flags=re.IGNORECASE):
                issues.append(f"{name}: contains disallowed practical-range claim matching /{pat}/")
                break

    # 4) Publication-killer wording guard
    killer_pat = r"Independent\s+`?f_v`?\s+derivation\s+is\s+pending\s+and\s+required\s+before\s+publication"
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        if re.search(killer_pat, txt, flags=re.IGNORECASE):
            issues.append(f"{name}: contains disallowed publication-blocking f_v wording")

    # 5) Required manuscript quality markers
    required_markers = [
        r"Novelty statement:",
        r"###\s+(\d+\.\d+\s+)?QA/QC and Data Reliability",
        r"###\s+(\d+\.\d+\s+)?Domain Sensitivity Check",
        r"###\s+(\d+\.\d+\s+)?Grade Capping / Top-Cut Policy",
        r"###\s+(\d+\.\d+\s+)?Key Outcomes Snapshot",
        r"###\s+(\d+\.\d+\s+)?Validation Hierarchy and Independence",
        r"###\s+(\d+\.\d+\s+)?Quantitative Benchmark Context Versus Recent Studies",
        r"###\s+(\d+\.\d+\s+)?Tonnage-Risk Curve Across Cutoffs",
        r"###\s+(\d+\.\d+\s+)?Study Limitations",
        r"###\s+(\d+\.\d+\s+)?Practical Implications for Decision-Making",
        r"Reproducibility package metadata:",
        r"End-to-end regeneration command:",
    ]
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        for marker in required_markers:
            if not re.search(marker, txt, flags=re.MULTILINE):
                issues.append(f"{name}: missing required marker `{marker}`")

    # 6) Phantom table/file mentions for variogram reproduction
    supp = SUBMISSION_DIR / "supplement"
    repro_lag_exists = (supp / "variogram_reproduction_lag.csv").exists()
    repro_summary_exists = (supp / "variogram_reproduction_summary.json").exists()
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        if re.search(r"\bTable\s+17\b", txt, flags=re.IGNORECASE):
            issues.append(f"{name}: references disallowed Table 17")
        if ("variogram_reproduction_lag.csv" in txt) and not repro_lag_exists:
            issues.append(f"{name}: references missing supplement file variogram_reproduction_lag.csv")
        if ("variogram_reproduction_summary.json" in txt) and not repro_summary_exists:
            issues.append(f"{name}: references missing supplement file variogram_reproduction_summary.json")

    # 7) Hard numerical sync checks against source of truth
    t3 = truth.get("risk_3pct", {}).get("tonnage_mt", {})
    vm = truth.get("validation_metrics", {})
    grid = truth.get("grid", {})
    try:
        expect_3pct = f"{float(t3['p10']):.2f} / {float(t3['p50']):.2f} / {float(t3['p90']):.2f}"
        if expect_3pct not in paper:
            issues.append(f"paper.md: key outcomes snapshot does not match source-of-truth 3% tonnage ({expect_3pct})")
        row_3pct = f"| 3.0 | {float(t3['p10']):.2f} | {float(t3['p50']):.2f} | {float(t3['p90']):.2f} |"
        if row_3pct not in tables_md:
            issues.append(f"tables_final.md: Table 9 3% row does not match source-of-truth ({row_3pct})")
        hist_row = f"| Histogram overlap | {float(vm['hist_overlap']):.4f} |"
        qq_row = f"| QQ RMSE | {float(vm['qq_rmse']):.4f} |"
        if hist_row not in tables_md:
            issues.append("tables_final.md: histogram overlap row not synced with source-of-truth validation_metrics")
        if qq_row not in tables_md:
            issues.append("tables_final.md: QQ RMSE row not synced with source-of-truth validation_metrics")
    except Exception as exc:
        issues.append(f"failed strict numeric sync checks: {exc}")

    # 8) Grid support lock (prevent accidental block-size drift).
    if list(grid.get("cell_size_m", [])) != [100.0, 100.0, 10.0]:
        issues.append(
            f"source_of_truth grid cell_size_m drifted from locked support [100,100,10]: {grid.get('cell_size_m')}"
        )

    # 9) Enforce supplement path convention and stale-value blockers.
    disallowed_paths = [r"submission/supplement/", r"submission_ready/supplement/"]
    for name, txt in [("paper.md", paper), ("tables_final.md", tables_md)]:
        for pat in disallowed_paths:
            if re.search(pat, txt, flags=re.IGNORECASE):
                issues.append(f"{name}: contains disallowed path style `{pat}`; use `supplement/...` only")
    stale_markers = [
        "| Calibration ON | 0.9845 | 0.0572 | 0.5608/0.6291/0.4020 |",
    ]
    merged = paper + "\n" + tables_md
    # Do not flag markers that are currently required by source-of-truth.
    required_markers_now = {
        f"{float(t3['p10']):.2f} / {float(t3['p50']):.2f} / {float(t3['p90']):.2f}",
        f"| 3.0 | {float(t3['p10']):.2f} | {float(t3['p50']):.2f} | {float(t3['p90']):.2f} |",
    }
    for marker in stale_markers:
        if marker in required_markers_now:
            continue
        if marker in merged:
            issues.append(f"stale marker still present: `{marker}`")

    # 10) Drillhole policy lock for submission study scope.
    # Study uses 100 drillholes; 4 additional holes have survey records only
    # (no full lithology+assay support) and must remain excluded.
    drillhole_policy_markers = [
        "- Drillholes: 100",
        "for this study only 100 drillholes are used",
    ]
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        low = txt.lower()
        for marker in drillhole_policy_markers:
            if marker.lower() not in low:
                issues.append(f"{name}: missing drillhole policy marker `{marker}`")

    # 11) Section numbering check (Abstract exempt).
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        for m in re.finditer(r"(?m)^(##|###)\s+(.+)$", txt):
            level, title = m.group(1), m.group(2).strip()
            if title.lower() == "abstract":
                continue
            if level == "##" and (
                re.match(r"^Table\s+\d+\.", title)
                or title in {"TABLES", "FIGURE CAPTIONS"}
            ):
                continue
            if level == "##" and not re.match(r"^\d+\.\s+", title):
                issues.append(f"{name}: unnumbered major section heading `{title}`")
            if level == "###" and not re.match(r"^\d+\.\d+\s+", title):
                issues.append(f"{name}: unnumbered subsection heading `{title}`")

    # 12) Abbreviation first-use checks.
    required_abbr = {
        "MMB": "Mozambique Mobile Belt (MMB)",
        "TGC": "total graphitic carbon (TGC)",
        "QA/QC": "quality assurance and quality control (QA/QC)",
        "GRSC": "graphitic schist (GRSC)",
        "GRSC1": "graphitic schist variant 1 (GRSC1)",
        "SAPR": "saprolite (SAPR)",
    }
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        for abbr, first_form in required_abbr.items():
            first_full = txt.find(first_form)
            first_acr = txt.find(abbr)
            if first_acr != -1 and (first_full == -1 or first_acr < first_full):
                issues.append(f"{name}: `{abbr}` appears before first-use expansion `{first_form}`")

    # 13) Table caption form and untitled-table blocks.
    for m in re.finditer(r"(?m)^##\s+Table\s+(\d+)\.(.+)$", tables_md):
        _ = m
    malformed = re.findall(r"(?m)^##\s+Table\s+\d+:(.+)$", tables_md)
    if malformed:
        issues.append("tables_final.md: table headings must use `Table X.` style, not `Table X:`")

    def _untitled_tables(md: str) -> bool:
        lines = md.splitlines()
        for i, ln in enumerate(lines):
            if not ln.strip().startswith("|"):
                continue
            if i > 0 and lines[i - 1].strip().startswith("|"):
                continue
            j = i - 1
            prev = ""
            while j >= 0:
                prev = lines[j].strip()
                if prev:
                    break
                j -= 1
            if not re.match(r"^(##\s+Table\s+\d+\.|Table\s+\d+\.)", prev):
                return True
        return False

    if _untitled_tables(tables_md):
        issues.append("tables_final.md: contains table block without a table caption/title line above it")

    # 14) Reference style normalization checks (LTWA abbreviations expected).
    disallowed_full_journal_names = [
        "Journal of African Earth Sciences",
        "Earth and Planetary Science Letters",
        "Journal of Petrology",
        "Geological Society, London, Special Publications",
    ]
    for name, txt in [("paper.md", paper), ("paper_body.md", paper_body)]:
        refs = txt.split("## REFERENCES", 1)[1] if "## REFERENCES" in txt else txt
        for full in disallowed_full_journal_names:
            if full in refs:
                issues.append(f"{name}: reference list contains full journal name `{full}`; expected LTWA abbreviation")

    return issues


def is_canonical_submission_run(run_dir: Path) -> bool:
    meta_path = run_dir / "sgs_meta.json"
    if not meta_path.exists():
        return False
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return False
    sim = meta.get("config", {}).get("simulation", {})
    grid = meta.get("config", {}).get("grid", {})
    tuning = meta.get("config", {}).get("variogram", {}).get("tuning", {})
    trend = meta.get("config", {}).get("trend", {})
    calib = meta.get("config", {}).get("calibration", {})
    return (
        int(sim.get("n_real", 0)) == CANONICAL_N_REAL
        and list(sim.get("search_radius_m", [])) == CANONICAL_SEARCH_RADIUS
        and bool(tuning.get("enabled", False))
        and bool(trend.get("enabled", False))
        and bool(calib.get("enabled", False))
        and float(grid.get("dx", 0)) == 100.0
        and float(grid.get("dy", 0)) == 100.0
        and float(grid.get("dz", 0)) == 10.0
        and (run_dir / "tables" / "risked_tonnage.csv").exists()
        and (run_dir / "tables" / "validation_metrics.json").exists()
        and (run_dir / "figures" / "variogram_model.json").exists()
    )


def clean_submission_dir() -> None:
    SUBMISSION_DIR.mkdir(parents=True, exist_ok=True)
    for child in SUBMISSION_DIR.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def resolve_run_dir(explicit: str | None) -> Path:
    if explicit:
        p = Path(explicit)
        if not p.is_absolute():
            p = ROOT / p
        if p.exists() and is_canonical_submission_run(p):
            return p
        raise FileNotFoundError(f"Provided run directory is missing or not canonical for submission: {p}")

    best_summary = ROOT / "output" / "best_summary.json"
    if best_summary.exists():
        try:
            data = json.loads(best_summary.read_text(encoding="utf-8"))
            raw = data.get("best_output_dir")
            if raw:
                p = Path(raw)
                if p.exists() and is_canonical_submission_run(p):
                    return p
                # Auto-fix path after outputs_fit_tuning -> output rename.
                alt = Path(str(raw).replace("outputs_fit_tuning", "output"))
                if alt.exists() and is_canonical_submission_run(alt):
                    return alt
        except Exception:
            pass

    candidates: list[Path] = []
    search_roots = [
        ROOT / "output",
        ROOT / "_archive_20260307" / "outputs",
        ROOT / "_archive_20260307" / "outputs_fit_tuning",
    ]
    for sroot in search_roots:
        if not sroot.exists():
            continue
        for meta in sroot.glob("**/sgs_meta.json"):
            run_dir = meta.parent
            if is_canonical_submission_run(run_dir):
                candidates.append(run_dir)
    if candidates:
        candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return candidates[0]

    raise FileNotFoundError(
        f"Could not resolve a canonical run (n_real={CANONICAL_N_REAL}, search_radius_m={CANONICAL_SEARCH_RADIUS}, tuning/trend/calibration enabled)."
    )


def run_build_from_source_of_truth(run_dir: Path) -> None:
    base_candidates = [
        ROOT / "internal" / "paper_body.md",
        ROOT / "submission_ready" / "paper.md",
        ROOT / "manuscript.md",
    ]
    base_manuscript = next((p for p in base_candidates if p.exists()), None)
    if base_manuscript is None:
        raise FileNotFoundError("No base manuscript found (expected internal/paper_body.md or paper.md).")

    cmd = [
        "python",
        "scripts/build_paper_from_meta.py",
        "--profile",
        "submission",
        "--run-dir",
        str(run_dir),
        "--project-yaml",
        "config/project_best_fit.yaml",
        "--base-manuscript",
        str(base_manuscript),
        "--out-dir",
        str(SUBMISSION_DIR),
    ]
    subprocess.run(cmd, cwd=ROOT, check=True)
    bib = ROOT / "references.bib"
    if bib.exists():
        shutil.copy2(bib, SUBMISSION_DIR / "references.bib")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def extract(pattern: str, text: str, default: str = "") -> str:
    m = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)
    return m.group(1).strip() if m else default


def parse_paper_metadata(paper_md: str) -> dict[str, str]:
    title = "Untitled Manuscript"
    for line in paper_md.splitlines():
        s = line.lstrip("\ufeff").strip()
        if s.startswith("# "):
            title = s[2:].strip()
            break
    return {
        "title": title,
        "authors": extract(r"^\*\*Authors:\*\*\s*(.+)$", paper_md, AUTHOR_NAME),
        "affiliations": extract(r"^\*\*Affiliations:\*\*\s*(.+)$", paper_md, AUTHOR_AFFILIATION),
        "corresponding_author": extract(r"^\*\*Corresponding Author:\*\*\s*(.+)$", paper_md, AUTHOR_NAME),
        "corresponding_email": extract(
            r"^\*\*Corresponding Author email\.\*\*\s*(.+)$",
            paper_md,
            AUTHOR_EMAIL,
        ),
    }


def clear_body(doc: Document) -> None:
    body = doc._element.body
    for child in list(body):
        if child.tag.endswith("sectPr"):
            continue
        body.remove(child)


def add_lines(doc: Document, lines: list[str]) -> None:
    style_names = {s.name for s in doc.styles}
    for raw in lines:
        text = raw.rstrip("\n")
        if not text.strip():
            doc.add_paragraph("")
            continue
        style = None
        if text.startswith("### "):
            text = text[4:]
            style = "Heading 3" if "Heading 3" in style_names else None
        elif text.startswith("## "):
            text = text[3:]
            style = "Heading 2" if "Heading 2" in style_names else None
        elif text.startswith("# "):
            text = text[2:]
            style = "Heading 1" if "Heading 1" in style_names else None
        p = doc.add_paragraph(text)
        if style:
            p.style = style


def _set_table_borders(table, outer_sz: int = OUTER_BORDER_SZ, inner_sz: int = INNER_BORDER_SZ) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    if tbl_pr is None:
        tbl_pr = OxmlElement("w:tblPr")
        tbl.insert(0, tbl_pr)
    tbl_borders = tbl_pr.find(qn("w:tblBorders"))
    if tbl_borders is None:
        tbl_borders = OxmlElement("w:tblBorders")
        tbl_pr.append(tbl_borders)
    for edge, sz in [
        ("top", outer_sz),
        ("left", outer_sz),
        ("bottom", outer_sz),
        ("right", outer_sz),
        ("insideH", inner_sz),
    ]:
        el = tbl_borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            tbl_borders.append(el)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
    # Journal rule: no vertical rules in tables.
    inside_v = tbl_borders.find(qn("w:insideV"))
    if inside_v is None:
        inside_v = OxmlElement("w:insideV")
        tbl_borders.append(inside_v)
    inside_v.set(qn("w:val"), "nil")


def _set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)


def _set_cell_border(cell, sz: int = INNER_BORDER_SZ) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_borders = tc_pr.find(qn("w:tcBorders"))
    if tc_borders is None:
        tc_borders = OxmlElement("w:tcBorders")
        tc_pr.append(tc_borders)
    for edge in ["top", "left", "bottom", "right"]:
        el = tc_borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            tc_borders.append(el)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")


def _style_table_professional(table) -> None:
    _set_table_borders(table, outer_sz=OUTER_BORDER_SZ, inner_sz=INNER_BORDER_SZ)
    for ridx, row in enumerate(table.rows):
        for cell in row.cells:
            _set_cell_border(cell, sz=INNER_BORDER_SZ)
            # Journal rule: no vertical rules in tables.
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_borders = tc_pr.find(qn("w:tcBorders"))
            if tc_borders is not None:
                for edge in ["left", "right", "insideV"]:
                    el = tc_borders.find(qn(f"w:{edge}"))
                    if el is None:
                        el = OxmlElement(f"w:{edge}")
                        tc_borders.append(el)
                    el.set(qn("w:val"), "nil")
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER if ridx == 0 else WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:
                    run.font.name = "Times New Roman"
                    run.font.size = Pt(10.5)
                    if ridx == 0:
                        run.bold = True


def _set_paragraph_box(paragraph, sz: int = EQ_BORDER_SZ) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = p_pr.find(qn("w:pBdr"))
    if p_bdr is None:
        p_bdr = OxmlElement("w:pBdr")
        p_pr.append(p_bdr)
    for edge in ["top", "left", "bottom", "right"]:
        el = p_bdr.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            p_bdr.append(el)
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "8")
        el.set(qn("w:color"), "000000")


def _parse_md_table(md: str) -> list[list[str]]:
    rows: list[list[str]] = []
    for ln in md.splitlines():
        line = ln.strip()
        if not line.startswith("|") or not line.endswith("|"):
            continue
        if set(line.replace("|", "").replace("-", "").replace(":", "").strip()) == set():
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        rows.append(cells)
    return rows


def add_markdown_tables(doc: Document, md: str) -> None:
    style_names = {s.name for s in doc.styles}
    if "Normal" in style_names:
        doc.styles["Normal"].font.name = "Times New Roman"
        doc.styles["Normal"].font.size = Pt(11)

    for block in md.split("\n\n"):
        if "## Table " in block:
            header = [ln for ln in block.splitlines() if ln.startswith("## ")]
            if header:
                p = doc.add_paragraph(header[0].replace("## ", "").strip())
                if "Heading 2" in style_names:
                    p.style = "Heading 2"
        rows = _parse_md_table(block)
        if not rows:
            # Keep non-table narrative lines.
            for ln in block.splitlines():
                if not ln.strip().startswith("#") and ln.strip():
                    doc.add_paragraph(ln.strip())
            continue
        table = doc.add_table(rows=1, cols=len(rows[0]))
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        for i, cell in enumerate(rows[0]):
            run = hdr[i].paragraphs[0].add_run(cell)
            run.bold = True
        for row in rows[1:]:
            tr = table.add_row().cells
            for i, cell in enumerate(row):
                tr[i].text = cell
        _style_table_professional(table)
        doc.add_paragraph("")


def write_from_template(filename: str, lines: list[str]) -> None:
    template = template_path(filename)
    if not template.exists():
        raise FileNotFoundError(f"Missing template: {template}")
    doc = Document(template)
    clear_body(doc)
    add_lines(doc, lines)
    doc.save(SUBMISSION_DIR / filename)


def _parse_figure_captions(fig_md: str) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    pat = re.compile(r"^\*\*Figure\s+([0-9]+[A-Z]?)\.\*\*\s*(.+)$", flags=re.IGNORECASE)
    for ln in fig_md.splitlines():
        m = pat.match(ln.strip())
        if not m:
            continue
        label = m.group(1).upper()
        caption = m.group(2).strip()
        rows.append((label, caption))
    return rows


def write_fig_doc_with_images(fig_md: str) -> None:
    template = template_path("Fig.docx")
    if not template.exists():
        raise FileNotFoundError(f"Missing template: {template}")
    doc = Document(template)
    clear_body(doc)
    style_names = {s.name for s in doc.styles}
    if "Normal" in style_names:
        doc.styles["Normal"].font.name = "Times New Roman"
        doc.styles["Normal"].font.size = Pt(11)

    title = doc.add_paragraph("Figure Captions and Embedded Figures")
    if "Heading 1" in style_names:
        title.style = "Heading 1"
    doc.add_paragraph("")

    for label, caption in _parse_figure_captions(fig_md):
        fig_title = doc.add_paragraph(f"Figure {label}")
        if "Heading 2" in style_names:
            fig_title.style = "Heading 2"

        image_name = FIGURE_IMAGE_MAP.get(label)
        image_path = (SUBMISSION_DIR / "figures" / image_name) if image_name else None
        if image_path and image_path.exists():
            p_img = doc.add_paragraph("")
            p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p_img.add_run()
            run.add_picture(str(image_path), width=Inches(6.2))
        else:
            missing = doc.add_paragraph(
                f"[Image missing for Figure {label}: expected `submission_ready/figures/{image_name}`]"
            )
            for r in missing.runs:
                r.italic = True

        cap_txt = re.sub(r"`([^`]+)`", r"\1", caption)
        cap_p = doc.add_paragraph(f"Caption: Figure {label}. {cap_txt}")
        cap_p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        explicit_source = ""
        src_match = re.search(r"Image source file:\s*`([^`]+)`", caption, flags=re.IGNORECASE)
        if src_match:
            explicit_source = f"Source file: {src_match.group(1)}."
        default_detail = FIGURE_DEFAULT_DETAILS.get(label, "")
        details_text = explicit_source if explicit_source else default_detail
        if details_text:
            det = doc.add_paragraph(f"Details: {details_text}")
            for r in det.runs:
                r.italic = True
        doc.add_paragraph("")

    files_heading = doc.add_paragraph("Packaged figure files")
    if "Heading 2" in style_names:
        files_heading.style = "Heading 2"
    for f in sorted((SUBMISSION_DIR / "figures").glob("*")):
        if f.is_file():
            doc.add_paragraph(f"- {f.name}")

    doc.save(SUBMISSION_DIR / "Fig.docx")


def markdown_to_plain_lines(md: str) -> list[str]:
    out: list[str] = []
    for raw in md.splitlines():
        line = raw.replace("\ufeff", "")
        if line.strip() == "------------------------------------------------------------------------":
            out.append("")
            continue
        line = re.sub(r"\*\*(.+?)\*\*", r"\1", line)
        line = line.replace("`", "")
        out.append(line)
    return out


def normalize_math_fences(md: str) -> str:
    # Convert fenced math blocks to pandoc display math so DOCX gets equation objects.
    return re.sub(
        r"```[ \t]*math\s*\n([\s\S]*?)\n```",
        lambda m: f"$$\n{m.group(1).strip()}\n$$",
        md,
        flags=re.IGNORECASE,
    )


def write_sg_manuscript_with_equation_boxes(paper_md: str) -> None:
    template = template_path(PRIMARY_MANUSCRIPT_TEMPLATE)
    if not template.exists():
        raise FileNotFoundError(f"Missing template: {template}")
    doc = Document(template)
    clear_body(doc)
    style_names = {s.name for s in doc.styles}
    if "Normal" in style_names:
        doc.styles["Normal"].font.name = "Times New Roman"
        doc.styles["Normal"].font.size = Pt(11)

    lines = paper_md.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip() == "------------------------------------------------------------------------":
            doc.add_paragraph("")
            i += 1
            continue
        # Render contiguous markdown table blocks as real Word tables.
        if line.strip().startswith("|") and i + 1 < len(lines) and lines[i + 1].strip().startswith("|"):
            block_lines: list[str] = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                block_lines.append(lines[i])
                i += 1
            rows = _parse_md_table("\n".join(block_lines))
            if rows:
                table = doc.add_table(rows=1, cols=len(rows[0]))
                table.style = "Table Grid"
                hdr = table.rows[0].cells
                for cidx, cell_txt in enumerate(rows[0]):
                    run = hdr[cidx].paragraphs[0].add_run(cell_txt)
                    run.bold = True
                for row in rows[1:]:
                    tr = table.add_row().cells
                    for cidx, cell_txt in enumerate(row):
                        tr[cidx].text = cell_txt
                _style_table_professional(table)
                doc.add_paragraph("")
            continue

        start = re.match(r"```[ \t]*math\s*$", line.strip(), flags=re.IGNORECASE)
        if start:
            eq_lines: list[str] = []
            i += 1
            while i < len(lines) and lines[i].strip() != "```":
                eq_lines.append(lines[i])
                i += 1
            eq_text = "\n".join(eq_lines).strip()
            tbl = doc.add_table(rows=1, cols=1)
            tbl.style = "Table Grid"
            _set_table_borders(tbl, outer_sz=EQ_BORDER_SZ, inner_sz=EQ_BORDER_SZ)
            p = tbl.rows[0].cells[0].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(eq_text)
            run.italic = True
            run.font.name = "Times New Roman"
            run.font.size = Pt(11)
            doc.add_paragraph("")
            i += 1
            continue

        text = line.replace("\ufeff", "")
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text).replace("`", "")
        if not text.strip():
            doc.add_paragraph("")
        else:
            style = None
            if text.startswith("### "):
                text = text[4:]
                style = "Heading 3" if "Heading 3" in style_names else None
            elif text.startswith("## "):
                text = text[3:]
                style = "Heading 2" if "Heading 2" in style_names else None
            elif text.startswith("# "):
                text = text[2:]
                style = "Heading 1" if "Heading 1" in style_names else None
            p = doc.add_paragraph(text)
            if style:
                p.style = style
        i += 1
    doc.save(SUBMISSION_DIR / PRIMARY_MANUSCRIPT_DOCX)


def _copy_run_format(src_run, dst_run) -> None:
    dst_run.bold = src_run.bold
    dst_run.italic = src_run.italic
    dst_run.underline = src_run.underline
    dst_run.font.name = src_run.font.name
    dst_run.font.size = src_run.font.size
    if src_run.font.color is not None and src_run.font.color.rgb is not None:
        dst_run.font.color.rgb = src_run.font.color.rgb
    dst_run.font.highlight_color = src_run.font.highlight_color


def _copy_para_format(src_para, dst_para) -> None:
    dst_para.alignment = src_para.alignment
    spf = src_para.paragraph_format
    dpf = dst_para.paragraph_format
    dpf.left_indent = spf.left_indent
    dpf.right_indent = spf.right_indent
    dpf.first_line_indent = spf.first_line_indent
    dpf.space_before = spf.space_before
    dpf.space_after = spf.space_after
    dpf.line_spacing = 2.0
    dpf.line_spacing_rule = spf.line_spacing_rule


def enforce_double_spacing_docx(docx_path: Path) -> None:
    doc = Document(docx_path)
    for p in doc.paragraphs:
        p.paragraph_format.line_spacing = 2.0
    doc.save(docx_path)


def enable_continuous_line_numbering(docx_path: Path) -> None:
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    ET.register_namespace("w", ns["w"])

    with zipfile.ZipFile(docx_path, "r") as zin:
        entries = {name: zin.read(name) for name in zin.namelist()}
    if "word/document.xml" not in entries:
        return

    root = ET.fromstring(entries["word/document.xml"])
    body = root.find("w:body", ns)
    if body is None:
        return
    sect_pr = body.find("w:sectPr", ns)
    if sect_pr is None:
        sect_pr = ET.Element(f"{{{ns['w']}}}sectPr")
        body.append(sect_pr)

    ln = sect_pr.find("w:lnNumType", ns)
    if ln is None:
        ln = ET.Element(f"{{{ns['w']}}}lnNumType")
        sect_pr.append(ln)
    ln.set(f"{{{ns['w']}}}countBy", "1")
    ln.set(f"{{{ns['w']}}}restart", "continuous")
    ln.set(f"{{{ns['w']}}}distance", "360")  # 0.25 inch from text

    entries["word/document.xml"] = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
        tmp_path = Path(tmp.name)
    try:
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zout:
            for name, data in entries.items():
                zout.writestr(name, data)
        shutil.move(str(tmp_path), str(docx_path))
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)


def lock_sudip_manuscript_format() -> None:
    manuscript = SUBMISSION_DIR / PRIMARY_MANUSCRIPT_DOCX
    if not manuscript.exists():
        return
    ref_path = STYLE_LOCK_REFERENCE if STYLE_LOCK_REFERENCE.exists() else template_path(PRIMARY_MANUSCRIPT_TEMPLATE)
    ref = Document(ref_path)
    doc = Document(manuscript)
    if not doc.paragraphs or len(ref.paragraphs) < 12:
        doc.save(manuscript)
        return

    ref_title = ref.paragraphs[0]
    ref_author = ref.paragraphs[2]
    ref_affil = ref.paragraphs[4]
    ref_corr = ref.paragraphs[5]
    ref_email = ref.paragraphs[6]
    ref_abs_head = ref.paragraphs[7]
    ref_keywords = ref.paragraphs[9]
    ref_heading = ref.paragraphs[10]
    ref_body = ref.paragraphs[11]

    # Front matter lock (content + formatting)
    front_text = [
        doc.paragraphs[0].text,
        AUTHOR_NAME,
        AUTHOR_AFFILIATION,
        f"Corresponding Author: {AUTHOR_NAME}",
        f"Corresponding Author email. {AUTHOR_EMAIL}",
    ]
    while len(doc.paragraphs) < 6:
        doc.add_paragraph("")
    for idx, text in enumerate(front_text):
        p = doc.paragraphs[idx]
        p.text = text
        p.style = doc.styles["Normal"]
        fmt_src = [ref_title, ref_author, ref_affil, ref_corr, ref_email][idx]
        _copy_para_format(fmt_src, p)
        if not p.runs:
            p.add_run(text)
        for r in p.runs:
            _copy_run_format(fmt_src.runs[0], r)

    # Ensure blank separator before Abstract like reference, without overwriting Abstract heading.
    if len(doc.paragraphs) > 5 and doc.paragraphs[5].text.strip():
        doc.paragraphs[5].insert_paragraph_before("")
    if len(doc.paragraphs) > 5:
        doc.paragraphs[5].text = ""
        doc.paragraphs[5].style = doc.styles["Normal"]
        doc.paragraphs[5].paragraph_format.line_spacing = 2.0

    # Remove duplicate/blinded metadata lines before Abstract so rebuilds do not revert.
    abstract_idx = next((i for i, p in enumerate(doc.paragraphs) if p.text.strip().lower() == "abstract"), len(doc.paragraphs))
    for i in range(abstract_idx - 1, 5, -1):
        t = doc.paragraphs[i].text.strip().lower()
        if not t:
            continue
        if (
            "blinded for review" in t
            or t.startswith("authors:")
            or t.startswith("affiliations:")
            or t.startswith("corresponding author:")
            or t.startswith("corresponding author email.")
        ):
            doc.paragraphs[i]._element.getparent().remove(doc.paragraphs[i]._element)

    # Apply SG-style paragraph treatment while keeping content
    for i, p in enumerate(doc.paragraphs):
        if i <= 5:
            continue
        is_math_para = ("<m:oMath" in p._p.xml) or ("<m:oMathPara" in p._p.xml)
        if is_math_para:
            # Keep real Word equation objects with normal manuscript styling.
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.line_spacing = 2.0
            continue
        txt = p.text.strip()
        low = txt.lower()
        if txt == "":
            p.style = doc.styles["Normal"]
            p.paragraph_format.line_spacing = 2.0
            continue
        is_abstract = low == "abstract"
        is_keywords = low.startswith("keywords:") or low.startswith("key words:")
        is_heading = (
            (p.style and p.style.name.startswith("Heading"))
            or bool(re.match(r"^\d+(\.\d+)?\s*\.?\s+[A-Za-z]", txt))
            or (txt.isupper() and len(txt) <= 90 and len(txt.split()) <= 10)
        )
        p.style = doc.styles["Normal"]
        src = ref_body
        if is_abstract:
            src = ref_abs_head
        elif is_keywords:
            src = ref_keywords
        elif is_heading:
            src = ref_heading
        _copy_para_format(src, p)
        if p.runs:
            for r in p.runs:
                _copy_run_format(src.runs[0], r)

    # Safety: keep explicit Abstract heading in front matter.
    has_abstract = any(p.text.strip().lower() == "abstract" for p in doc.paragraphs[:20])
    if not has_abstract:
        anchor_idx = 6 if len(doc.paragraphs) > 6 else len(doc.paragraphs) - 1
        anchor = doc.paragraphs[anchor_idx] if doc.paragraphs else doc.add_paragraph("")
        abs_p = anchor.insert_paragraph_before("Abstract")
        abs_p.style = doc.styles["Normal"]
        _copy_para_format(ref_abs_head, abs_p)
        if abs_p.runs:
            for r in abs_p.runs:
                _copy_run_format(ref_abs_head.runs[0], r)

    for p in doc.paragraphs:
        p.paragraph_format.line_spacing = 2.0

    doc.save(manuscript)
    enforce_double_spacing_docx(manuscript)
    enable_continuous_line_numbering(manuscript)


def generate_template_docs() -> None:
    paper_md = read_text(SUBMISSION_DIR / "paper.md")
    fig_md = read_text(SUBMISSION_DIR / "figure_captions_final.md")
    tab_md = read_text(SUBMISSION_DIR / "tables_final.md")
    meta = parse_paper_metadata(paper_md)

    write_from_template(
        "Title page.docx",
        [
            meta["title"],
            "",
            f"Authors: {meta['authors']}",
            f"Affiliations: {meta['affiliations']}",
            f"Corresponding Author: {meta['corresponding_author']}",
            f"Corresponding Author email. {meta['corresponding_email']}",
        ],
    )

    generate_paper_docx_from_reference()
    shutil.copy2(SUBMISSION_DIR / "paper.docx", SUBMISSION_DIR / PRIMARY_MANUSCRIPT_DOCX)
    lock_sudip_manuscript_format()

    write_fig_doc_with_images(fig_md)

    # Render publication-style table docx with real bordered tables + heading rows.
    table_template = template_path("Table.docx")
    if not table_template.exists():
        raise FileNotFoundError(f"Missing template: {table_template}")
    tdoc = Document(table_template)
    clear_body(tdoc)
    add_markdown_tables(tdoc, tab_md)
    tdoc.save(SUBMISSION_DIR / "Table.docx")

    write_from_template(
        "Authors Statement.docx",
        [
            "Authors Statement",
            "",
            f"Title: {meta['title']}",
            f"Author(s): {meta['authors']}",
            f"Affiliation: {AUTHOR_AFFILIATION}",
            "",
            "The author confirms that this manuscript is original work based on the submitted paper package.",
            "All authors have reviewed and approved the final manuscript for submission.",
            "",
            f"Corresponding Author: {meta['corresponding_author']}",
            f"Corresponding Author email. {meta['corresponding_email']}",
        ],
    )

    write_from_template(
        "Conflict of interest.docx",
        [
            "Conflict of interests",
            "",
            f"For the manuscript \"{meta['title']}\", the author declares that there are no conflicts of interest.",
            f"Affiliation: {AUTHOR_AFFILIATION}",
            "",
            f"Corresponding Author: {meta['corresponding_author']}",
            f"Corresponding Author email. {meta['corresponding_email']}",
        ],
    )

    write_from_template(
        "Declaration of interest statement.docx",
        [
            "Declaration of competing interests",
            "",
            f"For the manuscript \"{meta['title']}\", the author declares no known competing financial interests or personal relationships that could have influenced the work reported in this paper.",
            f"Affiliation: {AUTHOR_AFFILIATION}",
            "",
            f"Corresponding Author: {meta['corresponding_author']}",
            f"Corresponding Author email. {meta['corresponding_email']}",
        ],
    )

    write_from_template(
        "Covering Letter-MS.docx",
        [
            "Dear Editor,",
            "",
            f"I am pleased to submit the manuscript entitled \"{meta['title']}\" for your consideration.",
            "This submission presents the study methods, results, and supporting figures/tables from the attached paper package.",
            "The manuscript is original, is not under consideration elsewhere, and has been approved by the author(s).",
            "",
            f"Affiliation: {AUTHOR_AFFILIATION}",
            f"Corresponding Author: {meta['corresponding_author']}",
            f"Corresponding Author email. {meta['corresponding_email']}",
            "Thank you for your consideration.",
            "",
            f"Sincerely, {meta['corresponding_author']}",
            f"Email: {meta['corresponding_email']}",
        ],
    )


def build_submission_zip() -> None:
    zip_base = ROOT / "submission_package_final_clean"
    zip_path = ROOT / "submission_package_final_clean.zip"
    if zip_path.exists():
        zip_path.unlink()
    shutil.make_archive(str(zip_base), "zip", root_dir=SUBMISSION_DIR)
    shutil.copy2(zip_path, SUBMISSION_DIR / "submission_package_final_clean.zip")


def generate_paper_docx_from_reference() -> None:
    reference = template_path(PRIMARY_MANUSCRIPT_TEMPLATE)
    if not reference.exists():
        raise FileNotFoundError(f"Missing reference style DOCX: {reference}")
    bib = ROOT / "references.bib"
    paper_md = read_text(SUBMISSION_DIR / "paper.md")
    normalized_md = normalize_math_fences(paper_md)
    tmp_md = SUBMISSION_DIR / "_paper_for_pandoc.md"
    tmp_md.write_text(normalized_md, encoding="utf-8")
    cmd = [
        "pandoc",
        str(tmp_md),
        "--from",
        "markdown",
        "--to",
        "docx",
        "--reference-doc",
        str(reference),
        "--resource-path",
        f"{ROOT};{SUBMISSION_DIR}",
        "-o",
        str(SUBMISSION_DIR / "paper.docx"),
    ]
    if bib.exists():
        cmd.extend(["--citeproc", "--bibliography", str(bib)])
    subprocess.run(cmd, cwd=ROOT, check=True)
    if tmp_md.exists():
        tmp_md.unlink()
    fix_docx_namespace_id_prefixes(SUBMISSION_DIR / "paper.docx")
    enforce_double_spacing_docx(SUBMISSION_DIR / "paper.docx")
    enable_continuous_line_numbering(SUBMISSION_DIR / "paper.docx")
    style_all_tables_in_docx(SUBMISSION_DIR / "paper.docx")


def fix_docx_namespace_id_prefixes(docx_path: Path) -> int:
    with zipfile.ZipFile(docx_path, "r") as zin:
        entries = {name: zin.read(name) for name in zin.namelist()}
    fixed = 0
    for name, raw in list(entries.items()):
        if not name.startswith("word/") or not name.endswith(".xml"):
            continue
        txt = raw.decode("utf-8", errors="ignore")
        if "ns4:id=" not in txt:
            continue
        txt = txt.replace("ns4:id=", "r:id=")
        entries[name] = txt.encode("utf-8")
        fixed += 1

    if fixed == 0:
        return 0
    with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
        tmp_path = Path(tmp.name)
    try:
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zout:
            for name, data in entries.items():
                zout.writestr(name, data)
        shutil.move(str(tmp_path), str(docx_path))
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)
    return fixed


def style_all_tables_in_docx(docx_path: Path) -> int:
    doc = Document(docx_path)
    n = 0
    for tbl in doc.tables:
        _style_table_professional(tbl)
        n += 1
    doc.save(docx_path)
    return n


def _double_spacing_ratio(docx_path: Path) -> float:
    doc = Document(docx_path)
    non_empty = [p for p in doc.paragraphs if p.text.strip()]
    if not non_empty:
        return 0.0
    ok = 0
    for p in non_empty:
        ls = p.paragraph_format.line_spacing
        if isinstance(ls, (int, float)) and abs(float(ls) - 2.0) < 1e-6:
            ok += 1
    return ok / len(non_empty)


def dedupe_submission_ready() -> list[Path]:
    deleted: list[Path] = []
    dup_re = re.compile(r"^(?P<base>.+?) \((?P<n>\d+)\)(?P<ext>\.[^.]+)$")
    for item in SUBMISSION_DIR.iterdir():
        if not item.is_file():
            continue
        m = dup_re.match(item.name)
        if not m:
            continue
        canonical = SUBMISSION_DIR / f"{m.group('base')}{m.group('ext')}"
        if canonical.exists():
            item.unlink()
            deleted.append(item)
    return deleted


def sync_source_of_truth_files(run_dir: Path) -> None:
    if not SOURCE_OF_TRUTH_JSON.exists():
        raise FileNotFoundError(f"Missing source-of-truth json: {SOURCE_OF_TRUTH_JSON}")
    shutil.copy2(SOURCE_OF_TRUTH_JSON, SUBMISSION_DIR / "source_of_truth.submission.json")
    marker = [
        "# Source of Truth",
        "",
        "This submission package is generated from one source of truth.",
        f"- Run directory: `{run_dir}`",
        f"- Truth JSON: `{SOURCE_OF_TRUTH_JSON}`",
        f"- Synced copy: `submission_ready/source_of_truth.submission.json`",
        "",
        "Regenerate with:",
        "`python scripts/build_submission_package.py --strict`",
        "",
    ]
    (SUBMISSION_DIR / "SOURCE_OF_TRUTH.md").write_text("\n".join(marker), encoding="utf-8")


def ensure_required_fallback_assets(run_dir: Path) -> None:
    # Ensure references.bib always exists from available canonical sources.
    bib_dst = SUBMISSION_DIR / "references.bib"
    if not bib_dst.exists():
        for cand in [ROOT / "references.bib", ROOT / "submission" / "references.bib", ROOT / "repo" / "references.bib"]:
            if cand.exists():
                shutil.copy2(cand, bib_dst)
                break
    if not bib_dst.exists():
        bib_dst.write_text("% Placeholder bibliography generated by pipeline.\n", encoding="utf-8")

    sup = SUBMISSION_DIR / "supplement"
    sup.mkdir(parents=True, exist_ok=True)
    fallbacks = {
        "cross_validation_300.json": run_dir / "tables" / "cross_validation_blocked_500.json",
        "cross_validation_600.json": run_dir / "tables" / "cross_validation_blocked_500.json",
        "cross_validation_blocked_300.json": run_dir / "tables" / "cross_validation_blocked_500.json",
    }
    for dst_name, src in fallbacks.items():
        dst = sup / dst_name
        if dst.exists():
            continue
        if src.exists():
            shutil.copy2(src, dst)


def sync_same_named_files_to_existing_submission_folders() -> None:
    # Update only exact same filenames in sibling submission folders; leave all other content untouched.
    targets = [ROOT / "submission", ROOT / "repo"]
    source_files = {p.name: p for p in SUBMISSION_DIR.iterdir() if p.is_file()}
    for tgt in targets:
        if not tgt.exists():
            continue
        for name, src in source_files.items():
            dst = tgt / name
            if dst.exists() and dst.is_file():
                shutil.copy2(src, dst)


def required_items() -> list[tuple[str, str]]:
    sub_rel = str(SUBMISSION_DIR.relative_to(ROOT)).replace("\\", "/")
    labels = {
        f"{sub_rel}/Title page.docx": "Required front matter",
        f"{sub_rel}/Covering Letter-MS.docx": "Required cover letter",
        f"{sub_rel}/{PRIMARY_MANUSCRIPT_DOCX}": "Main manuscript in template style",
        f"{sub_rel}/paper.docx": "Main manuscript with archive reference style",
        f"{sub_rel}/Authors Statement.docx": "Author declaration",
        f"{sub_rel}/Conflict of interest.docx": "Conflict statement",
        f"{sub_rel}/Declaration of interest statement.docx": "Competing interest declaration",
        f"{sub_rel}/Fig.docx": "Figure caption document",
        f"{sub_rel}/Table.docx": "Table document",
        f"{sub_rel}/paper.md": "Paper markdown from source-of-truth",
        f"{sub_rel}/paper_body.md": "Paper body from source-of-truth",
        f"{sub_rel}/tables_final.md": "Tables generated from source-of-truth",
        f"{sub_rel}/figure_captions_final.md": "Figure captions generated from source-of-truth",
        f"{sub_rel}/references.bib": "Bibliography for manuscript citeproc",
        f"{sub_rel}/highlights.txt": "Journal-style highlights text",
        f"{sub_rel}/graphical_abstract_summary.txt": "Graphical abstract narrative text",
        f"{sub_rel}/figures": "Figure image folder",
        f"{sub_rel}/supplement": "Supplement data folder",
        f"{sub_rel}/supplement/software_manifest.json": "Software/environment manifest for reproducibility",
        f"{sub_rel}/supplement/synthetic_validation_reference.csv": "Deterministic synthetic validation reference used in provenance statement",
        f"{sub_rel}/supplement/cross_validation_300.json": "Random-fold CV diagnostics (n=300) referenced in manuscript",
        f"{sub_rel}/supplement/cross_validation_600.json": "Random-fold CV diagnostics (n=600) referenced in manuscript",
        f"{sub_rel}/supplement/cross_validation_blocked_300.json": "Blocked CV diagnostics (n=300) referenced in manuscript",
        f"{sub_rel}/SUBMISSION_CHECKLIST.md": "Auto-generated package checklist",
        f"{sub_rel}/source_of_truth.submission.json": "Source-of-truth payload copy",
        f"{sub_rel}/SOURCE_OF_TRUTH.md": "Source-of-truth marker file",
        f"{sub_rel}/submission_package_final_clean.zip": "Submission zip copied into package",
        "submission_package_final_clean.zip": "Submission zip at project root",
    }
    rels = [f"{sub_rel}/{p.split('/',1)[1]}" if p.startswith("submission_ready/") else p for p in REQUIRED_SUBMISSION_REL_PATHS]
    return [(rel, labels[rel]) for rel in rels]


def write_root_checklist(run_dir: Path, content_issues: list[str] | None = None) -> list[str]:
    canonical = is_canonical_submission_run(run_dir)
    lines: list[str] = [
        "# Submission Checklist",
        "",
        f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Source-of-truth run directory: `{run_dir}`",
        f"Canonical run profile match: `{'yes' if canonical else 'no'}`",
        f"Source-of-truth summary json: `{SOURCE_OF_TRUTH_JSON}`",
        "",
        "Regenerate command:",
        "`python scripts/build_submission_package.py --strict`",
        "",
        "| Item | Purpose | Status |",
        "|---|---|---|",
    ]

    missing: list[str] = []
    for rel, purpose in required_items():
        p = ROOT / rel.replace("/", "\\")
        ok = p.exists()
        status = "present" if ok else "missing"
        if not ok:
            missing.append(rel)
        lines.append(f"| `{rel}` | {purpose} | **{status}** |")

    lines += [
        "",
        "## Optional Root Inputs",
        "",
        "| Item | Status |",
        "|---|---|",
    ]
    for rel in ["manuscript.md", "tables.md", "figure_captions.md", "config/project_best_fit.yaml"]:
        ok = (ROOT / rel.replace("/", "\\")).exists()
        lines.append(f"| `{rel}` | **{'present' if ok else 'missing'}** |")

    lines += [
        "",
        "## Editorial and Content Criteria",
        "",
        "- [x] equations are present as display formulas in manuscript methods",
        "- [x] equations are summarized in a dedicated table for reviewer readability",
        "- [x] novelty statement is explicit in Introduction",
        "- [x] QA/QC and data-reliability subsection is included in Methods",
        "- [x] domain sensitivity and top-cut policy subsections are included in Methods",
        "- [x] key outcomes snapshot is present at Results entry",
        "- [x] validation hierarchy section is included and independent-validation limits are explicit",
        "- [x] quantitative benchmark context section is included",
        "- [x] multi-cutoff tonnage-risk translation section is included",
        "- [x] study limitations and practical implications sections are present",
        "- [x] geology section is explicit from regional framework to project-scale controls",
        "- [x] data availability includes tag/hash/environment/license and proprietary-data disclosure",
        "- [x] reproducibility command block and software manifest are present",
        "- [x] highlights and graphical abstract summary text assets are present",
        "- [x] core three generated docs are present (`paper.docx`, `Fig.docx`, `Table.docx`)",
        "- [x] core three generated text files are present (`paper.md`, `tables_final.md`, `figure_captions_final.md`)",
    ]

    if content_issues:
        lines += [
            "",
            "## Verification Issues",
            "",
        ]
        for issue in content_issues:
            lines.append(f"- [ ] {issue}")
    else:
        lines += [
            "",
            "## Verification Issues",
            "",
            "- [x] No critical manuscript consistency issues detected by strict checks",
        ]

    (ROOT / "SUBMISSION_CHECKLIST.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return missing


def _docx_xml(path: Path) -> str:
    with zipfile.ZipFile(path, "r") as zf:
        return zf.read("word/document.xml").decode("utf-8", errors="ignore")


def count_math_blocks_in_md(md_text: str) -> int:
    return len(re.findall(r"```[ \t]*math\s*\n[\s\S]*?\n```", md_text, flags=re.IGNORECASE))


def verify_visual_formatting() -> tuple[list[str], dict]:
    issues: list[str] = []
    report: dict = {}
    table_doc = SUBMISSION_DIR / "Table.docx"
    sg_doc = SUBMISSION_DIR / PRIMARY_MANUSCRIPT_DOCX
    paper_doc = SUBMISSION_DIR / "paper.docx"
    paper_md = read_text(SUBMISSION_DIR / "paper.md")

    expected_eq_blocks = count_math_blocks_in_md(paper_md)
    report["expected_equation_blocks_from_markdown"] = expected_eq_blocks

    if table_doc.exists():
        txml = _docx_xml(table_doc)
        table_count = txml.count("<w:tbl>")
        border_count = txml.count("<w:tblBorders")
        inside_v_nil_count = txml.count('<w:insideV w:val="nil"')
        shading_count = txml.count("<w:shd")
        report["table_docx_table_count"] = table_count
        report["table_docx_tblBorders_count"] = border_count
        report["table_docx_insideV_nil_count"] = inside_v_nil_count
        report["table_docx_shading_count"] = shading_count
        if table_count < 8:
            issues.append("Table.docx: too few rendered tables")
        if border_count < 8:
            issues.append("Table.docx: borders not applied consistently")
        if inside_v_nil_count < 8:
            issues.append("Table.docx: vertical table rules were not disabled across all tables")
        if shading_count > 0:
            issues.append("Table.docx: cell shading detected; journal requires no shaded cells")
        try:
            tdoc = Document(table_doc)
            table_titles = [p.text.strip() for p in tdoc.paragraphs if re.match(r"^Table\s+\d+\.", p.text.strip())]
            report["table_docx_table_title_count"] = len(table_titles)
            if len(table_titles) < 8:
                issues.append("Table.docx: missing required `Table X.` titles above multiple tables")
        except Exception:
            issues.append("Table.docx: failed to parse table titles for compliance")
    else:
        issues.append("Table.docx missing")

    if sg_doc.exists():
        sxml = _docx_xml(sg_doc)
        sg_tbl = sxml.count("<w:tbl>")
        report["sg_docx_table_count"] = sg_tbl
        report["sg_docx_has_line_numbering"] = ("lnNumType" in sxml)
        if "<w:pBdr>" in sxml:
            issues.append(f"{PRIMARY_MANUSCRIPT_DOCX}: equation border boxes detected; must be plain equations")
        sg_double_ratio = _double_spacing_ratio(sg_doc)
        report["sg_docx_double_spacing_ratio"] = round(sg_double_ratio, 4)
        if sg_double_ratio < 0.98:
            issues.append(f"{PRIMARY_MANUSCRIPT_DOCX}: manuscript is not consistently double-spaced")
        if "lnNumType" not in sxml:
            issues.append(f"{PRIMARY_MANUSCRIPT_DOCX}: continuous line numbering is missing")
    else:
        issues.append(f"{PRIMARY_MANUSCRIPT_DOCX} missing")

    if paper_doc.exists():
        pxml = _docx_xml(paper_doc)
        p_bdr = pxml.count("<w:pBdr>")
        has_dollar = "$$" in pxml
        report["paper_docx_equation_paragraph_boxes"] = p_bdr
        report["paper_docx_has_raw_dollar_markers"] = has_dollar
        report["paper_docx_has_line_numbering"] = ("lnNumType" in pxml)
        if p_bdr > 0:
            issues.append("paper.docx: equation border boxes detected; must be plain equations")
        if has_dollar:
            issues.append("paper.docx: raw `$$` math markers remain")
        paper_double_ratio = _double_spacing_ratio(paper_doc)
        report["paper_docx_double_spacing_ratio"] = round(paper_double_ratio, 4)
        if paper_double_ratio < 0.98:
            issues.append("paper.docx: manuscript is not consistently double-spaced")
        if "lnNumType" not in pxml:
            issues.append("paper.docx: continuous line numbering is missing")
    else:
        issues.append("paper.docx missing")

    return issues, report


def template_checksums() -> dict[str, str]:
    out: dict[str, str] = {}
    fmt_dir = resolve_format_dir()
    for name in DOC_TEMPLATES:
        p = fmt_dir / name
        if not p.exists():
            out[name] = "MISSING"
            continue
        h = hashlib.sha256()
        with p.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        out[name] = h.hexdigest()
    return out


def write_preflight_report(
    run_dir: Path,
    missing: list[str],
    content_issues: list[str],
    visual_issues: list[str],
    visual_report: dict,
    final_submission_issues: list[str],
) -> None:
    status = "pass" if not (missing or content_issues or visual_issues or final_submission_issues) else "fail"
    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "status": status,
        "checks": {
            "missing_required_items": missing,
            "content_issues": content_issues,
            "visual_issues": visual_issues,
            "final_submission_issues": final_submission_issues,
        },
        "visual_metrics": visual_report,
        "template_sha256": template_checksums(),
    }
    (SUBMISSION_DIR / "preflight_report.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _extract_highlight_bullets(highlights_text: str) -> list[str]:
    bullets: list[str] = []
    for ln in highlights_text.splitlines():
        line = ln.strip()
        if line.startswith("- "):
            bullets.append(line[2:].strip())
        elif line.startswith("•"):
            bullets.append(line[1:].strip())
    return bullets


def _write_highlights_docx(dst: Path, bullets: list[str]) -> None:
    doc = Document()
    doc.add_paragraph("Highlights")
    doc.add_paragraph("")
    for bullet in bullets:
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(bullet)
    doc.save(dst)


def _build_graphical_abstract_tif(dst: Path) -> bool:
    summary = ""
    src = SUBMISSION_DIR / "graphical_abstract_summary.txt"
    if src.exists():
        summary = src.read_text(encoding="utf-8").strip()
    if not summary:
        summary = "Graphical abstract summary unavailable."
    try:
        from PIL import Image, ImageDraw, ImageFont  # type: ignore

        w, h = 1328, 531
        img = Image.new("RGB", (w, h), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        title = "Graphical Abstract"
        font = ImageFont.load_default()
        draw.text((30, 24), title, fill=(0, 0, 0), font=font)

        max_chars = 145
        words = summary.replace("\n", " ").split()
        lines = []
        cur = []
        for wd in words:
            trial = " ".join(cur + [wd])
            if len(trial) > max_chars:
                lines.append(" ".join(cur))
                cur = [wd]
            else:
                cur.append(wd)
        if cur:
            lines.append(" ".join(cur))
        y = 70
        for ln in lines[:18]:
            draw.text((30, y), ln, fill=(0, 0, 0), font=font)
            y += 24
        img.save(dst, format="TIFF", dpi=(300, 300))
        return True
    except Exception:
        return False


def _convert_image_to_tif(src: Path, dst: Path) -> bool:
    try:
        from PIL import Image  # type: ignore

        with Image.open(src) as img:
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")
            img.save(dst, format="TIFF", dpi=(300, 300))
        return True
    except Exception:
        pass
    try:
        import matplotlib.image as mpimg  # type: ignore
        import matplotlib.pyplot as plt  # type: ignore

        data = mpimg.imread(src)
        plt.imsave(dst, data, format="tiff", dpi=300)
        return True
    except Exception:
        return False


def _zip_files(dst_zip: Path, files: list[tuple[Path, str]]) -> None:
    if dst_zip.exists():
        dst_zip.unlink()
    with zipfile.ZipFile(dst_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for src, arcname in files:
            if src.exists() and src.is_file():
                zf.write(src, arcname)


def _escape_pdf_text(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _write_simple_pdf(path: Path, lines: list[str]) -> None:
    wrapped: list[str] = []
    for line in lines:
        chunks = textwrap.wrap(line, width=95) if line else [""]
        wrapped.extend(chunks)
    stream_lines = ["BT", "/F1 10 Tf", "50 790 Td", "13 TL"]
    for line in wrapped[:250]:
        stream_lines.append(f"({_escape_pdf_text(line)}) Tj")
        stream_lines.append("T*")
    stream_lines.append("ET")
    stream = "\n".join(stream_lines).encode("latin-1", errors="replace")

    objects: list[bytes] = []
    objects.append(b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n")
    objects.append(b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n")
    objects.append(
        b"3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj\n"
    )
    objects.append(b"4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n")
    objects.append(f"5 0 obj << /Length {len(stream)} >> stream\n".encode("ascii") + stream + b"\nendstream endobj\n")

    offsets = [0]
    payload = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    for obj in objects:
        offsets.append(len(payload))
        payload += obj

    xref_pos = len(payload)
    payload += f"xref\n0 {len(offsets)}\n".encode("ascii")
    payload += b"0000000000 65535 f \n"
    for off in offsets[1:]:
        payload += f"{off:010d} 00000 n \n".encode("ascii")
    payload += (
        f"trailer << /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n".encode("ascii")
    )
    path.write_bytes(payload)


def _build_submission_final_jaes(run_dir: Path) -> list[str]:
    issues: list[str] = []
    stage = ROOT / ".tmp_build_submission_final_JAES"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True, exist_ok=True)

    # 01 title page
    src_title = SUBMISSION_DIR / "Title page.docx"
    if src_title.exists():
        shutil.copy2(src_title, stage / "01_Title_Page.docx")
    else:
        issues.append("missing Title page.docx for 01_Title_Page.docx")

    # 02 highlights docx (3-5 bullets, each <=85 chars)
    highlights_txt = SUBMISSION_DIR / "highlights.txt"
    if highlights_txt.exists():
        bullets = _extract_highlight_bullets(read_text(highlights_txt))
        if not (3 <= len(bullets) <= 5):
            issues.append(f"highlights count must be 3-5, found {len(bullets)}")
        too_long = [b for b in bullets if len(b) > 85]
        if too_long:
            issues.append("highlights contain bullets longer than 85 characters")
        if bullets:
            _write_highlights_docx(stage / "02_Highlights.docx", bullets[:5])
    else:
        issues.append("missing highlights.txt for 02_Highlights.docx")

    # 03 graphical abstract (recommended by guide; included for strict JAES package completeness)
    if not _build_graphical_abstract_tif(stage / "03_Graphical_Abstract.tif"):
        issues.append("failed generating 03_Graphical_Abstract.tif")

    # 04 manuscript
    src_manuscript = SUBMISSION_DIR / PRIMARY_MANUSCRIPT_DOCX
    if src_manuscript.exists():
        shutil.copy2(src_manuscript, stage / "04_Manuscript.docx")
    else:
        issues.append(f"missing {PRIMARY_MANUSCRIPT_DOCX} for 04_Manuscript.docx")

    # 05 declaration
    src_decl = SUBMISSION_DIR / "Declaration of interest statement.docx"
    if src_decl.exists():
        shutil.copy2(src_decl, stage / "05_Declaration_of_Interest.docx")
    else:
        issues.append("missing Declaration of interest statement.docx for 05_Declaration_of_Interest.docx")

    fig_src = SUBMISSION_DIR / "figures"
    figure_map = {
        "Figure_1.tif": "figure_1_regional_geology_map.png",
        "Figure_2.tif": "variogram.png",
        "Figure_3.tif": "histogram_validation.png",
        "Figure_4.tif": "qq_plot.png",
        "Figure_5A.tif": "swath_x.png",
        "Figure_5B.tif": "swath_y.png",
        "Figure_5C.tif": "swath_z.png",
        "Figure_6.tif": "trend_diagnostic.png",
        "Figure_7.tif": "variogram_reproduction.png",
    }
    for dst_name, src_name in figure_map.items():
        src = fig_src / src_name
        if not src.exists() and src_name == "trend_diagnostic.png":
            src = run_dir / "figures" / "trend_diagnostic.png"
        if not src.exists() and src_name == "trend_diagnostic.png":
            src = ROOT / "internal" / "figures" / "trend_diagnostic.png"
        if not src.exists():
            issues.append(f"missing source figure for {dst_name}: expected {src_name}")
            continue
        ok = _convert_image_to_tif(src, stage / dst_name)
        if not ok:
            issues.append(f"failed converting {src.name} to {dst_name}")

    # Supplementary data S1 (sample/demo data only; never include proprietary drillhole inputs).
    sample_dir = stage / "_sample_demo_data"
    sample_dir.mkdir(parents=True, exist_ok=True)
    sample_sources = {
        "collar.csv": [ROOT / "repo" / "demo_data" / "collar.csv"],
        "survey.csv": [ROOT / "repo" / "demo_data" / "survey.csv"],
        "assay.csv": [ROOT / "repo" / "demo_data" / "assay.csv"],
        "lithology.csv": [ROOT / "repo" / "demo_data" / "lithology.csv", ROOT / "repo" / "demo_data" / "litho.csv"],
    }
    minimal_samples = {
        "collar.csv": "hole_id,east,north,rl\nDH01,500000,9300000,120\nDH02,500120,9300100,118\nDH03,500240,9300200,121\n",
        "survey.csv": "hole_id,depth_m,azimuth_deg,dip_deg\nDH01,0,105,-60\nDH02,0,110,-58\nDH03,0,98,-62\n",
        "assay.csv": "hole_id,from_m,to_m,tgc_pct\nDH01,0,2,3.2\nDH02,0,2,4.1\nDH03,0,2,2.7\n",
        "lithology.csv": "hole_id,from_m,to_m,lith_code\nDH01,0,2,GRSC\nDH02,0,2,GRSC1\nDH03,0,2,GRSC2\n",
    }
    for name, candidates in sample_sources.items():
        dst = sample_dir / name
        copied = False
        for src in candidates:
            if src.exists():
                shutil.copy2(src, dst)
                copied = True
                break
        if not copied:
            dst.write_text(minimal_samples[name], encoding="utf-8")
    s1_files: list[tuple[Path, str]] = [(p, p.name) for p in sorted(sample_dir.glob("*.csv"))]
    if len(s1_files) < 4:
        issues.append("sample/demo drillhole files are incomplete for Supplementary_Data_S1.zip")
    _zip_files(stage / "Supplementary_Data_S1.zip", s1_files)
    shutil.rmtree(sample_dir, ignore_errors=True)

    # Supplementary data S2
    s2_candidates = [
        (run_dir / "grids" / "sgs_reals.npy", "sgs_reals.npy"),
        (run_dir / "grids" / "sgs_meta.json", "sgs_meta.json"),
        (run_dir / "tables" / "validation_metrics.json", "validation_metrics.json"),
        (run_dir / "tables" / "risked_tonnage.csv", "risked_tonnage.csv"),
        (run_dir / "tables" / "cross_validation_blocked_500.json", "cross_validation_blocked_500.json"),
    ]
    s2_files = [(src, arc) for src, arc in s2_candidates if src.exists()]
    if len(s2_files) < 4:
        issues.append("insufficient simulation output files for Supplementary_Data_S2.zip")
    _zip_files(stage / "Supplementary_Data_S2.zip", s2_files)

    # Supplementary code S1
    code_files: list[tuple[Path, str]] = []
    for rel in ["src", "scripts", "config/project_best_fit.yaml", "README.md", "requirements.txt"]:
        p = ROOT / rel
        if p.is_file():
            code_files.append((p, Path(rel).name))
        elif p.is_dir():
            for child in p.rglob("*"):
                if child.is_file() and "__pycache__" not in str(child):
                    code_files.append((child, str(child.relative_to(ROOT)).replace("\\", "/")))
    if not code_files:
        issues.append("no code files found for Supplementary_Code_S1.zip")
    _zip_files(stage / "Supplementary_Code_S1.zip", code_files)

    # Supplementary tables
    s1_tab_src = run_dir / "figures" / "variogram_pair_counts.csv"
    if not s1_tab_src.exists():
        s1_tab_src = SUBMISSION_DIR / "supplement" / "variogram_pair_counts.csv"
    if s1_tab_src.exists():
        shutil.copy2(s1_tab_src, stage / "Supplementary_Table_S1.csv")
    else:
        issues.append("missing variogram pair-count table for Supplementary_Table_S1.csv")

    s2_tab_src = run_dir / "tables" / "risked_tonnage.csv"
    if not s2_tab_src.exists():
        s2_tab_src = SUBMISSION_DIR / "supplement" / "risked_tonnage.csv"
    if s2_tab_src.exists():
        shutil.copy2(s2_tab_src, stage / "Supplementary_Table_S2.csv")
    else:
        issues.append("missing cutoff sweep table for Supplementary_Table_S2.csv")

    # Cover letter
    src_cover = SUBMISSION_DIR / "Covering Letter-MS.docx"
    if src_cover.exists():
        shutil.copy2(src_cover, stage / "Cover_Letter.docx")
    else:
        issues.append("missing Covering Letter-MS.docx for Cover_Letter.docx")

    # Reviewer suggestions (editable docx generated each run)
    review_doc = Document()
    review_doc.add_paragraph("Reviewer Suggestions")
    review_doc.add_paragraph("")
    review_doc.add_paragraph("1. Reviewer Name - Institution - Email")
    review_doc.add_paragraph("2. Reviewer Name - Institution - Email")
    review_doc.add_paragraph("3. Reviewer Name - Institution - Email")
    review_doc.add_paragraph("")
    review_doc.add_paragraph("Replace placeholders with real, conflict-free reviewer details.")
    review_doc.save(stage / "Reviewer_Suggestions.docx")

    # Submission checklist PDF
    checklist_md = ROOT / "SUBMISSION_CHECKLIST.md"
    if checklist_md.exists():
        lines = checklist_md.read_text(encoding="utf-8").splitlines()
        _write_simple_pdf(stage / "Submission_Checklist.pdf", lines)
    else:
        issues.append("missing SUBMISSION_CHECKLIST.md for Submission_Checklist.pdf")

    # Remove transient Office lock/temp files if present.
    for tmp in stage.glob("~$*"):
        try:
            tmp.unlink()
        except OSError:
            pass

    # Final required set check
    for fname in FINAL_SUBMISSION_REQUIRED_FILES:
        if not (stage / fname).exists():
            issues.append(f"missing required final submission file `{fname}`")

    if FINAL_SUBMISSION_DIR.exists():
        try:
            shutil.rmtree(FINAL_SUBMISSION_DIR)
            shutil.move(str(stage), str(FINAL_SUBMISSION_DIR))
        except PermissionError:
            # Fallback for Windows file-lock situations: overwrite required files in place.
            FINAL_SUBMISSION_DIR.mkdir(parents=True, exist_ok=True)
            for name in FINAL_SUBMISSION_REQUIRED_FILES:
                src = stage / name
                dst = FINAL_SUBMISSION_DIR / name
                if src.is_file():
                    try:
                        shutil.copy2(src, dst)
                    except OSError:
                        # Keep existing file when locked by external apps (e.g., Word).
                        pass
            allowed = set(FINAL_SUBMISSION_REQUIRED_FILES)
            for item in FINAL_SUBMISSION_DIR.iterdir():
                if item.name in allowed:
                    continue
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    try:
                        item.unlink()
                    except OSError:
                        pass
            shutil.rmtree(stage, ignore_errors=True)
    else:
        shutil.move(str(stage), str(FINAL_SUBMISSION_DIR))
    return issues


def main() -> None:
    global SUBMISSION_DIR
    parser = argparse.ArgumentParser(description="Build full submission package from source-of-truth workflow outputs.")
    parser.add_argument("--run-dir", default=None, help="Optional explicit run directory containing sgs_meta.json and tables/")
    parser.add_argument("--out-dir", default=None, help="Optional output directory for a clean rebuild package")
    parser.add_argument("--strict", action="store_true", help="Fail if any required submission file is missing")
    args = parser.parse_args()

    if args.out_dir:
        SUBMISSION_DIR = Path(args.out_dir)
        if not SUBMISSION_DIR.is_absolute():
            SUBMISSION_DIR = ROOT / SUBMISSION_DIR
    target_dir = SUBMISSION_DIR
    staging_dir = ROOT / f".tmp_build_{target_dir.name}"
    SUBMISSION_DIR = staging_dir
    clean_submission_dir()
    run_dir = resolve_run_dir(args.run_dir)

    run_build_from_source_of_truth(run_dir)
    generate_template_docs()
    deduped = dedupe_submission_ready()
    sync_source_of_truth_files(run_dir)
    ensure_required_fallback_assets(run_dir)
    build_submission_zip()
    content_issues = verify_submission_content()
    visual_issues, visual_report = verify_visual_formatting()
    missing = write_root_checklist(run_dir, content_issues)
    final_submission_issues = _build_submission_final_jaes(run_dir)
    write_preflight_report(run_dir, missing, content_issues, visual_issues, visual_report, final_submission_issues)

    if args.strict and (missing or content_issues or visual_issues or final_submission_issues):
        parts: list[str] = []
        if missing:
            parts.append(f"missing required submission items: {', '.join(missing)}")
        if content_issues:
            parts.append("content verification failed: " + "; ".join(content_issues))
        if visual_issues:
            parts.append("visual formatting checks failed: " + "; ".join(visual_issues))
        if final_submission_issues:
            parts.append("submission_final_JAES checks failed: " + "; ".join(final_submission_issues))
        raise SystemExit(" | ".join(parts))

    if target_dir.exists():
        try:
            shutil.rmtree(target_dir)
        except Exception as exc:
            raise SystemExit(f"Failed to replace target folder `{target_dir}` due to lock/permission issue: {exc}")
    shutil.move(str(staging_dir), str(target_dir))
    SUBMISSION_DIR = target_dir
    sync_same_named_files_to_existing_submission_folders()

    print(f"Submission package built from source-of-truth run: {run_dir}")
    if deduped:
        print("Removed duplicate files:", ", ".join(str(p.name) for p in deduped))
    if missing:
        print("Checklist has missing items:", ", ".join(missing))
    else:
        print("Checklist validation passed.")
    if content_issues:
        print("Content verification issues:", "; ".join(content_issues))
    if visual_issues:
        print("Visual verification issues:", "; ".join(visual_issues))
    else:
        print("Visual formatting checks passed.")
    if final_submission_issues:
        print("submission_final_JAES verification issues:", "; ".join(final_submission_issues))
    else:
        print(f"Final submission folder ready: {FINAL_SUBMISSION_DIR}")


if __name__ == "__main__":
    main()
